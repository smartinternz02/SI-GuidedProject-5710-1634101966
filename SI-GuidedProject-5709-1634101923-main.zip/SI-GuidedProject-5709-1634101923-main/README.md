# SI-GuidedProject-5709-1634101923

download dataset from https://www.kaggle.com/wilhelmberghammer/chest-xrays-pneumonia-detection
